
package unitech.itemgroup;

import unitech.item.SparkBadgeItem;

import unitech.UnitechModElements;

import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;

@UnitechModElements.ModElement.Tag
public class UnitechmainItemGroup extends UnitechModElements.ModElement {
	public UnitechmainItemGroup(UnitechModElements instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		tab = new ItemGroup("tabunitechmain") {
			@OnlyIn(Dist.CLIENT)
			@Override
			public ItemStack createIcon() {
				return new ItemStack(SparkBadgeItem.block);
			}

			@OnlyIn(Dist.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}

	public static ItemGroup tab;
}
