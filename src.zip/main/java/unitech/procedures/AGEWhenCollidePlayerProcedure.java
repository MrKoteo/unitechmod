package unitech.procedures;

import unitech.UnitechMod;

import net.minecraft.util.DamageSource;
import net.minecraft.potion.Effects;
import net.minecraft.potion.EffectInstance;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;

import java.util.Map;

public class AGEWhenCollidePlayerProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				UnitechMod.LOGGER.warn("Failed to load dependency entity for procedure AGEWhenCollidePlayer!");
			return;
		}
		if (dependencies.get("sourceentity") == null) {
			if (!dependencies.containsKey("sourceentity"))
				UnitechMod.LOGGER.warn("Failed to load dependency sourceentity for procedure AGEWhenCollidePlayer!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		Entity sourceentity = (Entity) dependencies.get("sourceentity");
		double rint = 0;
		rint = Math.random();
		sourceentity.attackEntityFrom(DamageSource.MAGIC, (float) 8);
		if (rint < 0.02) {
			entity.setAir((int) 0);
			if (sourceentity instanceof LivingEntity)
				((LivingEntity) sourceentity).addPotionEffect(new EffectInstance(Effects.BLINDNESS, (int) 100, (int) 1, (false), (false)));
			if (sourceentity instanceof LivingEntity)
				((LivingEntity) sourceentity).addPotionEffect(new EffectInstance(Effects.SLOWNESS, (int) 100, (int) 2, (false), (true)));
		}
		if (entity instanceof LivingEntity)
			((LivingEntity) entity).addPotionEffect(new EffectInstance(Effects.INSTANT_HEALTH, (int) 1, (int) 4, (false), (true)));
	}
}
