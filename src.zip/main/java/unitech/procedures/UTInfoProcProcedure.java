package unitech.procedures;

import unitech.UnitechMod;

import net.minecraft.world.server.ServerWorld;
import net.minecraft.world.World;
import net.minecraft.world.IWorld;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.math.vector.Vector2f;
import net.minecraft.entity.Entity;
import net.minecraft.command.ICommandSource;
import net.minecraft.command.CommandSource;

import java.util.Map;
import java.util.HashMap;

public class UTInfoProcProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				UnitechMod.LOGGER.warn("Failed to load dependency world for procedure UTInfoProc!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				UnitechMod.LOGGER.warn("Failed to load dependency entity for procedure UTInfoProc!");
			return;
		}
		if (dependencies.get("cmdparams") == null) {
			if (!dependencies.containsKey("cmdparams"))
				UnitechMod.LOGGER.warn("Failed to load dependency cmdparams for procedure UTInfoProc!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		Entity entity = (Entity) dependencies.get("entity");
		HashMap cmdparams = (HashMap) dependencies.get("cmdparams");
		if ((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText()).equals("info")) {
			if (world instanceof ServerWorld) {
				((World) world).getServer().getCommandManager().handleCommand(
						new CommandSource(ICommandSource.DUMMY, new Vector3d((entity.getPosX()), (entity.getPosY()), (entity.getPosZ())),
								Vector2f.ZERO, (ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(), null)
								.withFeedbackDisabled(),
						"tellraw @p [\"\",{\"text\":\"-=-=-=-=-=-=- IniTech -=-=-=-=-=-=-\",\"color\":\"light_purple\"},{\"text\":\"\\n \\u041f\\u0440\\u0438\\u0432\\u0435\\u0442\\u0441\\u0442\\u0432\\u0443\\u0435\\u043c \\u0412\\u0430\\u0441 \\u0432 \\u043c\\u0438\\u0440\\u0435 Whylone (\\u0432\\u0430\\u0439\\u043b\\u043e\\u043d) !\\n\\u0417\\u0434\\u0435\\u0441\\u044c \\u0432\\u0430\\u043c \\u043f\\u0440\\u0435\\u0434\\u0441\\u0442\\u043e\\u0438\\u0442 \\u0432\\u044b\\u0436\\u0438\\u0442\\u044c, \\u0440\\u0430\\u0437\\u0432\\u0438\\u0442\\u044c\\u0441\\u044f \\u0434\\u043e\\n\\u0432\\u044b\\u0441\\u043e\\u043a\\u043e\\u0433\\u043e \\u0443\\u0440\\u043e\\u0432\\u043d\\u044f \\u0442\\u0435\\u0445\\u043d\\u043e\\u043b\\u043e\\u0433\\u0438\\u0439 \\u0438 \\u0443\\u043d\\u0438\\u0447\\u0442\\u043e\\u0436\\u0438\\u0442\\u044c\\n\\u043f\\u0440\\u0430\\u0432\\u044f\\u0449\\u0438\\u0435 \\u0432 \\u044d\\u0442\\u043e\\u043c \\u043c\\u0438\\u0440\\u0435 \\u0444\\u0440\\u0430\\u043a\\u0446\\u0438\\u0438!\\n \\u041f\\u0443\\u0442\\u0435\\u0448\\u0435\\u0441\\u0442\\u0432\\u0443\\u0439\\u0442\\u0435, \\u0432\\u043e\\u044e\\u0439\\u0442\\u0435, \\u0440\\u0443\\u0448\\u044c\\u0442\\u0435 \\u0438 \\u0442\\u0432\\u043e\\u0440\\u0438\\u0442\\u0435!\\n\\u0421\\u043c\\u043e\\u0442\\u0440\\u0438\\u0442\\u0435 \\u043b\\u0438\\u0448\\u044c, \\u0447\\u0442\\u043e\\u0432\\u044b \\u0432\\u0430\\u0441 \\u043d\\u0435 \\u0441\\u043a\\u0443\\u0448\\u0430\\u043b\\u0438 :D ^_^\\n\\n\"},{\"text\":\"[i] \\u0421\\u043e\\u043e\\u0431\\u0449\\u0438\\u0442\\u044c \\u043e\\u0431 \\u043e\\u0448\\u0438\\u0431\\u043a\\u0430\\u0445 \\u0438\\u043b\\u0438 \\u043f\\u0440\\u0435\\u0434\\u043b\\u043e\\u0436\\u0438\\u0442\\u044c \\u0441\\u0432\\u043e\\u0438\\n\\u0438\\u0434\\u0435\\u0438 \\u0434\\u043b\\u044f \\u043c\\u043e\\u0434\\u043f\\u0430\\u043a\\u0430 \\u043c\\u043e\\u0436\\u043d\\u043e \\u0432 \",\"color\":\"aqua\"},{\"text\":\"\\u0414\\u0438\\u0441\\u043a\\u043e\\u0440\\u0434\\u0435\",\"color\":\"blue\",\"clickEvent\":{\"action\":\"open_url\",\"value\":\"https://discord.gg/sQWNkhkNDf\"}},{\"text\":\"\\n\"},{\"text\":\"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\",\"color\":\"light_purple\"}]");
			}
		} else if ((new Object() {
			public String getText() {
				String param = (String) cmdparams.get("0");
				if (param != null) {
					return param;
				}
				return "";
			}
		}.getText()).equals("help")) {
			if (world instanceof ServerWorld) {
				((World) world).getServer().getCommandManager().handleCommand(
						new CommandSource(ICommandSource.DUMMY, new Vector3d((entity.getPosX()), (entity.getPosY()), (entity.getPosZ())),
								Vector2f.ZERO, (ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(), null)
								.withFeedbackDisabled(),
						"tellraw @p [\"\",{\"text\":\"-=-=-=-=-=-=- IniTech -=-=-=-=-=-=-\",\"color\":\"light_purple\"},{\"text\":\"\\n\"},{\"text\":\"[i] \\u0421\\u043e\\u043e\\u0431\\u0449\\u0438\\u0442\\u044c \\u043e\\u0431 \\u043e\\u0448\\u0438\\u0431\\u043a\\u0430\\u0445 \\u0438\\u043b\\u0438 \\u043f\\u0440\\u0435\\u0434\\u043b\\u043e\\u0436\\u0438\\u0442\\u044c \\u0441\\u0432\\u043e\\u0438\\n\\u0438\\u0434\\u0435\\u0438 \\u0434\\u043b\\u044f \\u043c\\u043e\\u0434\\u043f\\u0430\\u043a\\u0430 \\u043c\\u043e\\u0436\\u043d\\u043e \\u0432 \",\"color\":\"aqua\"},{\"text\":\"\\u0414\\u0438\\u0441\\u043a\\u043e\\u0440\\u0434\\u0435\",\"color\":\"blue\",\"clickEvent\":{\"action\":\"open_url\",\"value\":\"https://discord.gg/sQWNkhkNDf\"}},{\"text\":\"\\n\\n \\u0418\\u043d\\u0444\\u043e\\u0440\\u043c\\u0430\\u0446\\u0438\\u044e \\u043f\\u043e \\u0442\\u043e\\u043c\\u0443, _\"},{\"text\":\"\\u0447\\u0442\\u043e \\u0434\\u0435\\u043b\\u0430\\u0442\\u044c\",\"italic\":true},{\"text\":\"_ \\u0438 \\u043a\\u0430\\u043a\\n\\\"\\u043f\\u0440\\u043e\\u0445\\u043e\\u0434\\u0438\\u0442\\u044c\\\" \\u0441\\u0431\\u043e\\u0440\\u043a\\u0443 - \\u0441\\u043c\\u043e\\u0442\\u0440\\u0438\\u0442\\u0435 \\u0432 \\u043c\\u0435\\u043d\\u044e \\u041a\\u0432\\u0435\\u0441\\u0442\\u043e\\u0432!\\n \\u0421\\u043f\\u0438\\u0441\\u043e\\u043a \\u0443\\u0441\\u0442\\u0430\\u043d\\u043e\\u0432\\u043b\\u0435\\u043d\\u043d\\u044b\\u0445 \\u043c\\u043e\\u0434\\u043e\\u0432 \\u043c\\u043e\\u0436\\u043d\\u043e \\u043f\\u043e\\u0441\\u043c\\u043e\\u0442\\u0440\\u0435\\u0442\\u044c\\n\\u0432\\u043e \\u0432\\u043a\\u043b\\u0430\\u0434\\u043a\\u0435 \"},{\"text\":\"Mods\",\"color\":\"green\"},{\"text\":\" \\u0432 \\u043c\\u0435\\u043d\\u044e \\u043f\\u0430\\u0443\\u0437\\u044b.\\n \"},{\"text\":\"\\u0418 \\u0443\\u0431\\u0435\\u0434\\u0438\\u0442\\u0435\\u043b\\u044c\\u043d\\u0430\\u044f \\u043f\\u0440\\u043e\\u0441\\u044c\\u0431\\u0430 -\",\"color\":\"gray\"},{\"text\":\" \\u041d\\u0435 \\u043c\\u0435\\u043d\\u044f\\u0442\\u044c \\u043a\\u043e\\u043d\\u0444\\u0438\\u0433\\u0438,\\n\\u0435\\u0441\\u043b\\u0438 \\u043d\\u0435 \\u0437\\u043d\\u0430\\u0435\\u0442\\u0435, \\u0447\\u0442\\u043e \\u0434\\u0435\\u043b\\u0430\\u0435\\u0442\\u0435 \",\"color\":\"red\"},{\"text\":\"!\",\"bold\":true,\"color\":\"red\"},{\"text\":\"\\n\"},{\"text\":\"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-\",\"color\":\"light_purple\"}]");
			}
		} else {
			if (world instanceof ServerWorld) {
				((World) world).getServer().getCommandManager().handleCommand(
						new CommandSource(ICommandSource.DUMMY, new Vector3d((entity.getPosX()), (entity.getPosY()), (entity.getPosZ())),
								Vector2f.ZERO, (ServerWorld) world, 4, "", new StringTextComponent(""), ((World) world).getServer(), null)
								.withFeedbackDisabled(),
						"tellraw @p {\"text\":\"Invalid argument!\",\"color\":\"red\"}");
			}
		}
	}
}
