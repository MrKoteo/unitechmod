
package unitech.item;

import unitech.itemgroup.UnitechmainItemGroup;

import unitech.UnitechModElements;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.world.World;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.block.BlockState;

import java.util.List;

@UnitechModElements.ModElement.Tag
public class GoldCoinItem extends UnitechModElements.ModElement {
	@ObjectHolder("unitech:gold_coin")
	public static final Item block = null;

	public GoldCoinItem(UnitechModElements instance) {
		super(instance, 200);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(UnitechmainItemGroup.tab).maxStackSize(64).rarity(Rarity.UNCOMMON));
			setRegistryName("gold_coin");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}

		@Override
		public void addInformation(ItemStack itemstack, World world, List<ITextComponent> list, ITooltipFlag flag) {
			super.addInformation(itemstack, world, list, flag);
			list.add(new StringTextComponent("100 coins \u00A4"));
		}
	}
}
