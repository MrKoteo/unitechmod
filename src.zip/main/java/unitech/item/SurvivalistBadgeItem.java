
package unitech.item;

import unitech.itemgroup.UnitechintItemGroup;

import unitech.UnitechModElements;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

@UnitechModElements.ModElement.Tag
public class SurvivalistBadgeItem extends UnitechModElements.ModElement {
	@ObjectHolder("unitech:survivalist_badge")
	public static final Item block = null;

	public SurvivalistBadgeItem(UnitechModElements instance) {
		super(instance, 133);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(UnitechintItemGroup.tab).maxStackSize(1).isImmuneToFire().rarity(Rarity.RARE));
			setRegistryName("survivalist_badge");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1.5F;
		}
	}
}
