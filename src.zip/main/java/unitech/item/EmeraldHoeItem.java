
package unitech.item;

import unitech.itemgroup.UnitechmainItemGroup;

import unitech.UnitechModElements;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.item.HoeItem;

@UnitechModElements.ModElement.Tag
public class EmeraldHoeItem extends UnitechModElements.ModElement {
	@ObjectHolder("unitech:emerald_hoe")
	public static final Item block = null;

	public EmeraldHoeItem(UnitechModElements instance) {
		super(instance, 114);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new HoeItem(new IItemTier() {
			public int getMaxUses() {
				return 1500;
			}

			public float getEfficiency() {
				return 8f;
			}

			public float getAttackDamage() {
				return 0.5f;
			}

			public int getHarvestLevel() {
				return 3;
			}

			public int getEnchantability() {
				return 16;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(Items.EMERALD));
			}
		}, 0, -0.0000000000000004f, new Item.Properties().group(UnitechmainItemGroup.tab)) {
		}.setRegistryName("emerald_hoe"));
	}
}
