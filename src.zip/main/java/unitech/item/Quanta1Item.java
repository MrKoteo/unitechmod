
package unitech.item;

import unitech.itemgroup.UnitechmainItemGroup;

import unitech.UnitechModElements;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

@UnitechModElements.ModElement.Tag
public class Quanta1Item extends UnitechModElements.ModElement {
	@ObjectHolder("unitech:quanta_1")
	public static final Item block = null;

	public Quanta1Item(UnitechModElements instance) {
		super(instance, 49);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(UnitechmainItemGroup.tab).maxStackSize(10000).rarity(Rarity.COMMON));
			setRegistryName("quanta_1");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}
	}
}
