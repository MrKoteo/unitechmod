package unitech.procedures;

import unitech.UnitechModVariables;

import unitech.UnitechMod;

import net.minecraft.world.IWorld;
import net.minecraft.entity.Entity;

import java.util.Map;

public class GetDeathsCountProcProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				UnitechMod.LOGGER.warn("Failed to load dependency world for procedure GetDeathsCountProc!");
			return;
		}
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				UnitechMod.LOGGER.warn("Failed to load dependency entity for procedure GetDeathsCountProc!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		Entity entity = (Entity) dependencies.get("entity");
		double deathsCount = 0;
		if (UnitechModVariables.MapVariables.get(world).showDeaths != true) {
			UnitechModVariables.MapVariables.get(world).showDeaths = (true);
			UnitechModVariables.MapVariables.get(world).syncData(world);
			{
				Entity _ent = entity;
				if (!_ent.world.isRemote && _ent.world.getServer() != null) {
					_ent.world.getServer().getCommandManager().handleCommand(_ent.getCommandSource().withFeedbackDisabled().withPermissionLevel(4),
							"scoreboard objectives setdisplay sidebar deathsCountX");
				}
			}
		} else {
			UnitechModVariables.MapVariables.get(world).showDeaths = (false);
			UnitechModVariables.MapVariables.get(world).syncData(world);
			{
				Entity _ent = entity;
				if (!_ent.world.isRemote && _ent.world.getServer() != null) {
					_ent.world.getServer().getCommandManager().handleCommand(_ent.getCommandSource().withFeedbackDisabled().withPermissionLevel(4),
							"scoreboard objectives setdisplay sidebar");
				}
			}
		}
	}
}
