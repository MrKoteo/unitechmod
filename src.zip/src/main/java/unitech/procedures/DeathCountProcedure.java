package unitech.procedures;

import unitech.UnitechMod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;

import net.minecraft.util.text.StringTextComponent;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.ScoreCriteria;
import net.minecraft.entity.Entity;

import java.util.Map;
import java.util.HashMap;

public class DeathCountProcedure {
	@Mod.EventBusSubscriber
	private static class GlobalTrigger {
		@SubscribeEvent
		public static void onPlayerRespawned(PlayerEvent.PlayerRespawnEvent event) {
			Entity entity = event.getPlayer();
			Map<String, Object> dependencies = new HashMap<>();
			dependencies.put("x", entity.getPosX());
			dependencies.put("y", entity.getPosY());
			dependencies.put("z", entity.getPosZ());
			dependencies.put("world", entity.world);
			dependencies.put("entity", entity);
			dependencies.put("endconquered", event.isEndConquered());
			dependencies.put("event", event);
			executeProcedure(dependencies);
		}
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			if (!dependencies.containsKey("entity"))
				UnitechMod.LOGGER.warn("Failed to load dependency entity for procedure DeathCount!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (new Object() {
			public int getScore(String score, Entity _ent) {
				Scoreboard _sc = _ent.world.getScoreboard();
				ScoreObjective _so = _sc.getObjective(score);
				if (_so != null)
					return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
				return 0;
			}
		}.getScore("deathsCountX", entity) != 0) {
			{
				Entity _ent = entity;
				Scoreboard _sc = _ent.world.getScoreboard();
				ScoreObjective _so = _sc.getObjective("deathsCountX");
				if (_so == null)
					_so = _sc.addObjective("deathsCountX", ScoreCriteria.DUMMY, new StringTextComponent("deathsCountX"),
							ScoreCriteria.RenderType.INTEGER);
				_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) (new Object() {
					public int getScore(String score, Entity _ent) {
						Scoreboard _sc = _ent.world.getScoreboard();
						ScoreObjective _so = _sc.getObjective(score);
						if (_so != null)
							return _sc.getOrCreateScore(_ent.getScoreboardName(), _so).getScorePoints();
						return 0;
					}
				}.getScore("deathsCountX", entity) + 1));
			}
		} else {
			{
				Entity _ent = entity;
				Scoreboard _sc = _ent.world.getScoreboard();
				ScoreObjective _so = _sc.getObjective("deathsCountX");
				if (_so == null)
					_so = _sc.addObjective("deathsCountX", ScoreCriteria.DUMMY, new StringTextComponent("deathsCountX"),
							ScoreCriteria.RenderType.INTEGER);
				_sc.getOrCreateScore(_ent.getScoreboardName(), _so).setScorePoints((int) 1);
			}
		}
	}
}
