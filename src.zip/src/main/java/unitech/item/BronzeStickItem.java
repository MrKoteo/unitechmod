
package unitech.item;

import unitech.itemgroup.UnitechmainItemGroup;

import unitech.UnitechModElements;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.Rarity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.block.BlockState;

@UnitechModElements.ModElement.Tag
public class BronzeStickItem extends UnitechModElements.ModElement {
	@ObjectHolder("unitech:bronze_rod")
	public static final Item block = null;

	public BronzeStickItem(UnitechModElements instance) {
		super(instance, 77);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	public static class ItemCustom extends Item {
		public ItemCustom() {
			super(new Item.Properties().group(UnitechmainItemGroup.tab).maxStackSize(64).rarity(Rarity.COMMON));
			setRegistryName("bronze_rod");
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, BlockState par2Block) {
			return 1F;
		}
	}
}
